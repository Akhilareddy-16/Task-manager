const express = require("express");

const router = express.Router();

const Task = require("../models/Task");


// CREATE TASK
router.post("/", async (req, res) => {

  try {

    const { title, description } = req.body;

    const newTask = new Task({
      title,
      description,
    });

    await newTask.save();

    res.json({
      message: "Task Created Successfully",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// GET TASKS
router.get("/", async (req, res) => {

  try {

    const tasks = await Task.find();

    res.json(tasks);

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// DELETE TASK
router.delete("/:id", async (req, res) => {

  try {

    await Task.findByIdAndDelete(req.params.id);

    res.json({
      message: "Task Deleted",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// UPDATE TASK
router.put("/:id", async (req, res) => {

  try {

    const { title, description } = req.body;

    await Task.findByIdAndUpdate(req.params.id, {
      title,
      description,
    });

    res.json({
      message: "Task Updated",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});

module.exports = router;