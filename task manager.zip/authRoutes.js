const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();

const User = require("../models/User");


// REGISTER
router.post("/register", async (req, res) => {

  try {

    const { name, email, password } = req.body;

    const user = new User({
      name,
      email,
      password,
    });

    await user.save();

    res.json({
      message: "User Registered Successfully",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// LOGIN
router.post("/login", async (req, res) => {

  try {

    const { email, password } = req.body;

    const user = await User.findOne({
      email,
      password,
    });

    if (!user) {

      return res.status(400).json({
        message: "Invalid Credentials",
      });

    }

    const token = jwt.sign(
      { id: user._id },
      "secretkey"
    );

    res.json({
      token,
      message: "Login Successful",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});

module.exports = router;