import { useEffect, useState } from "react";
import API from "./services/api";
import "./App.css";

function App() {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const [tasks, setTasks] = useState([]);

  const [editId, setEditId] = useState(null);


  // REGISTER
  const registerUser = async () => {

    try {

      const res = await API.post("/auth/register", {
        name,
        email,
        password,
      });

      alert(res.data.message);

    } catch (error) {

      console.log(error);

    }

  };


  // LOGIN
  const loginUser = async () => {

    try {

      const res = await API.post("/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", res.data.token);

      alert("Login Successful");

    } catch (error) {

      console.log(error);

    }

  };


  // GET TASKS
  const getTasks = async () => {

    try {

      const res = await API.get("/tasks");

      setTasks(res.data);

    } catch (error) {

      console.log(error);

    }

  };


  // CREATE TASK
  const createTask = async () => {

    try {

      await API.post("/tasks", {
        title,
        description,
      });

      alert("Task Created");

      setTitle("");
      setDescription("");

      getTasks();

    } catch (error) {

      console.log(error);

    }

  };


  // DELETE TASK
  const deleteTask = async (id) => {

    try {

      await API.delete(`/tasks/${id}`);

      getTasks();

    } catch (error) {

      console.log(error);

    }

  };


  // EDIT TASK
  const editTask = (task) => {

    setEditId(task._id);

    setTitle(task.title);

    setDescription(task.description);

  };


  // UPDATE TASK
  const updateTask = async () => {

    try {

      await API.put(`/tasks/${editId}`, {
        title,
        description,
      });

      alert("Task Updated");

      setEditId(null);

      setTitle("");
      setDescription("");

      getTasks();

    } catch (error) {

      console.log(error);

    }

  };


  useEffect(() => {

    getTasks();

  }, []);


  return (

    <div className="container">

      <h1>Task Manager App</h1>

      <div className="card">

        <h2>Register / Login</h2>

        <input
          type="text"
          placeholder="Name"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="email"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={registerUser}>
          Register
        </button>

        <button onClick={loginUser}>
          Login
        </button>

      </div>


      <div className="card">

        <h2>
          {editId ? "Update Task" : "Create Task"}
        </h2>

        <input
          type="text"
          placeholder="Task Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />

        <textarea
          placeholder="Task Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        {
          editId ? (
            <button onClick={updateTask}>
              Update Task
            </button>
          ) : (
            <button onClick={createTask}>
              Create Task
            </button>
          )
        }

      </div>


      <div className="card">

        <h2>My Tasks</h2>

        {
          tasks.map((task) => (

            <div className="task" key={task._id}>

              <h3>{task.title}</h3>

              <p>{task.description}</p>

              <div className="btns">

                <button onClick={() => editTask(task)}>
                  Edit
                </button>

                <button onClick={() => deleteTask(task._id)}>
                  Delete
                </button>

              </div>

            </div>

          ))
        }

      </div>

    </div>

  );

}

export default App;